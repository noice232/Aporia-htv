import type { GraphNode, GraphEdge } from '../stores/graph'

const CLUSTERS: Record<string, {
  center: [number, number, number]
  color: [number, number, number]
  colorAlt: [number, number, number]
  papers: string[]
  paperCount: number
}> = {
  computer_vision: {
    center: [-18, 8, -6],
    color: [0.34, 0.87, 0.96],
    colorAlt: [0.2, 0.65, 0.9],
    paperCount: 214302,
    papers: [
      'DINOv2: Learning Robust Visual Features',
      'Segment Anything Model (SAM)',
      'ViT-22B: Scaling Vision Transformers',
      'InternImage: Exploring Large-Scale Vision Foundation',
      'EVA-02: A Visual Representation for Neon Genesis',
      'Florence-2: Advancing Unified Representation',
      'Depth Anything: Unleashing the Power of Large-Scale',
      'Grounding DINO: Marrying DINO with Grounded Pre-Training',
      'RAM: Recognize Anything Model',
      'Co-DETR: DETRs with Collaborative Hybrid Assignments',
      'YOLO-World: Real-Time Open-Vocabulary Object Detection',
      'SAM 2: Segment Anything in Images and Videos',
      'OWLv2: Scaling Open-Vocabulary Object Detection',
      'Mask2Former: Masked-attention Mask Transformer',
      'BEVFormer: Learning Bird Eye View Representation',
    ],
  },
  generative_models: {
    center: [20, -4, 8],
    color: [0.91, 0.56, 0.93],
    colorAlt: [0.75, 0.35, 0.85],
    paperCount: 387611,
    papers: [
      'Stable Diffusion 3: Scaling Rectified Flow Transformers',
      'DALL-E 3: Improving Image Generation with Better Captions',
      'Consistency Models: Direct Distillation of Diffusion',
      'PixArt-α: Fast Training of Diffusion Transformer',
      'SDXL: Improving Latent Diffusion for High-Resolution',
      'LCM: Latent Consistency Models',
      'Playground v2.5: Three Insights towards Enhancing',
      'EMU Edit: Precise Image Editing via Recognition',
      'IP-Adapter: Text Compatible Image Prompt Adapter',
      'InstantID: Zero-shot Identity-Preserving Generation',
      'FLUX.1: Black Forest Labs Rectified Flow Transformer',
      'Sora: Creating Video from Text',
      'Imagen 3: Better Photorealism with DeepMind',
    ],
  },
  nlp: {
    center: [4, 18, 16],
    color: [0.31, 0.91, 0.73],
    colorAlt: [0.2, 0.75, 0.55],
    paperCount: 298421,
    papers: [
      'LLaMA 3: Open Foundation and Fine-Tuned Models',
      'Mixtral of Experts: Efficient Sparse Transformer',
      'Phi-3: Small Language Models with Strong Reasoning',
      'GPT-4 Technical Report',
      'Gemini: A Family of Highly Capable Multimodal Models',
      'RWKV: Reinventing RNNs for the Transformer Era',
      'Mamba: Linear-Time Sequence Modeling with Selective',
      'Retrieval-Augmented Generation for Knowledge-Intensive',
      'Constitutional AI: Harmlessness from AI Feedback',
      'Direct Preference Optimization: Your Language Model',
      'Zephyr: Direct Distillation of LM Alignment',
      'Qwen2: Alibaba Technical Report',
      'DeepSeek-V2: A Strong Open-Source MoE Language Model',
      'Command R+: Scalable RAG-Optimized LLM',
    ],
  },
  reinforcement_learning: {
    center: [-14, -16, -18],
    color: [0.73, 0.60, 1.0],
    colorAlt: [0.55, 0.4, 0.9],
    paperCount: 176843,
    papers: [
      'Decision Transformer: Reinforcement Learning via Seq',
      'RLHF: Training Language Models to Follow Instructions',
      'PPO-Max: Scalable Proximal Policy Optimization',
      'DreamerV3: Mastering Diverse Domains through World',
      'TD-MPC2: Scalable, Robust World Models',
      'METRA: Scalable Unsupervised RL with Metric-Aware',
      'Eureka: Human-Level Reward Design via Coding LLMs',
      'Q-Transformer: Scalable Offline Reinforcement Learning',
      'RT-2: Vision-Language-Action Models Transfer Web',
      'Gato: A Generalist Agent',
    ],
  },
  multimodal: {
    center: [14, 12, -16],
    color: [0.96, 0.65, 0.14],
    colorAlt: [0.85, 0.5, 0.1],
    paperCount: 298421,
    papers: [
      'LLaVA-1.5: Improved Baselines with Visual Instruction',
      'CogVLM: Visual Expert for Pretrained Language Models',
      'InternVL: Scaling up Vision Foundation Models',
      'Qwen-VL: A Versatile Vision-Language Model',
      'BLIP-3: A Family of Fully Open Multimodal Models',
      'Cambrian-1: A Fully Open, Vision-Centric Exploration',
      'Video-LLaMA: An Instruction-tuned Audio-Visual LLM',
      'ImageBind: One Embedding Space To Bind Them All',
      'NExT-GPT: Any-to-Any Multimodal LLM',
      'Ferret: Refer and Ground Anything Anywhere at Any',
      'MiniGPT-4: Enhancing Vision-Language Understanding',
    ],
  },
}

function seededRandom(seed: number) {
  let s = seed
  return () => {
    s = (s * 16807 + 0) % 2147483647
    return (s - 1) / 2147483646
  }
}

function gaussian(rand: () => number): number {
  let u = 0, v = 0
  while (u === 0) u = rand()
  while (v === 0) v = rand()
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v)
}

export function generateMockGraph(): { nodes: GraphNode[]; edges: GraphEdge[] } {
  const nodes: GraphNode[] = []
  const edges: GraphEdge[] = []
  const rand = seededRandom(42)

  for (const [cluster, data] of Object.entries(CLUSTERS)) {
    for (let i = 0; i < data.papers.length; i++) {
      const r = 3.5
      const position: [number, number, number] = [
        data.center[0] + gaussian(rand) * r,
        data.center[1] + gaussian(rand) * r,
        data.center[2] + gaussian(rand) * r,
      ]
      const size = 0.2 + rand() * 0.4

      nodes.push({
        id: `${cluster}_${i}`,
        label: data.papers[i],
        type: 'paper',
        cluster,
        position,
        color: rand() > 0.4 ? data.color : data.colorAlt,
        size,
        metadata: {
          year: 2023 + Math.floor(rand() * 2),
          venue: ['NeurIPS', 'ICML', 'ICLR', 'CVPR', 'ECCV', 'ACL', 'EMNLP'][Math.floor(rand() * 7)],
          citations: Math.floor(rand() * 500) + 10,
          paperCount: data.paperCount,
        },
      })
    }
  }

  const edgeTypes: GraphEdge['type'][] = ['citation', 'dependency', 'evidence', 'contradiction']

  for (const node of nodes) {
    const sameCluster = nodes.filter((n) => n.cluster === node.cluster && n.id !== node.id)
    const intraCount = Math.min(Math.floor(rand() * 3) + 1, sameCluster.length)
    for (let i = 0; i < intraCount; i++) {
      const target = sameCluster[Math.floor(rand() * sameCluster.length)]
      const edgeId = [node.id, target.id].sort().join('__')
      if (!edges.find((e) => e.id === edgeId)) {
        edges.push({
          id: edgeId,
          source: node.id,
          target: target.id,
          type: edgeTypes[Math.floor(rand() * 3)],
          weight: 0.3 + rand() * 0.7,
        })
      }
    }

    if (rand() > 0.65) {
      const otherNodes = nodes.filter((n) => n.cluster !== node.cluster)
      if (otherNodes.length > 0) {
        const target = otherNodes[Math.floor(rand() * otherNodes.length)]
        const edgeId = [node.id, target.id].sort().join('__')
        if (!edges.find((e) => e.id === edgeId)) {
          edges.push({
            id: edgeId,
            source: node.id,
            target: target.id,
            type: rand() > 0.7 ? 'contradiction' : 'citation',
            weight: 0.1 + rand() * 0.4,
          })
        }
      }
    }
  }

  return { nodes, edges }
}

export interface NebulaCluster {
  id: string
  label: string
  center: [number, number, number]
  color: [number, number, number]
  colorAlt: [number, number, number]
  paperCount: number
  coreParticles: Float32Array
  coreColors: Float32Array
  coreSizes: Float32Array
  haloParticles: Float32Array
  haloColors: Float32Array
  haloSizes: Float32Array
}

const CLUSTER_LABELS: Record<string, string> = {
  computer_vision: 'Computer Vision',
  generative_models: 'Diffusion',
  nlp: 'Natural Language Processing',
  reinforcement_learning: 'Reinforcement Learning',
  multimodal: 'Video & Multimodal',
}

export function generateNebulae(): NebulaCluster[] {
  const rand = seededRandom(777)
  const nebulae: NebulaCluster[] = []

  for (const [id, data] of Object.entries(CLUSTERS)) {
    const coreCount = 600
    const haloCount = 1200

    const coreParticles = new Float32Array(coreCount * 3)
    const coreColors = new Float32Array(coreCount * 3)
    const coreSizes = new Float32Array(coreCount)

    for (let i = 0; i < coreCount; i++) {
      const r = 4.0
      coreParticles[i * 3] = data.center[0] + gaussian(rand) * r
      coreParticles[i * 3 + 1] = data.center[1] + gaussian(rand) * r * 0.7
      coreParticles[i * 3 + 2] = data.center[2] + gaussian(rand) * r

      const t = rand()
      coreColors[i * 3] = data.color[0] * t + data.colorAlt[0] * (1 - t)
      coreColors[i * 3 + 1] = data.color[1] * t + data.colorAlt[1] * (1 - t)
      coreColors[i * 3 + 2] = data.color[2] * t + data.colorAlt[2] * (1 - t)

      coreSizes[i] = 0.08 + rand() * 0.25
    }

    const haloParticles = new Float32Array(haloCount * 3)
    const haloColors = new Float32Array(haloCount * 3)
    const haloSizes = new Float32Array(haloCount)

    for (let i = 0; i < haloCount; i++) {
      const r = 8.0
      haloParticles[i * 3] = data.center[0] + gaussian(rand) * r
      haloParticles[i * 3 + 1] = data.center[1] + gaussian(rand) * r * 0.65
      haloParticles[i * 3 + 2] = data.center[2] + gaussian(rand) * r

      const t = rand()
      haloColors[i * 3] = data.color[0] * t + data.colorAlt[0] * (1 - t)
      haloColors[i * 3 + 1] = data.color[1] * t + data.colorAlt[1] * (1 - t)
      haloColors[i * 3 + 2] = data.color[2] * t + data.colorAlt[2] * (1 - t)

      haloSizes[i] = 0.03 + rand() * 0.1
    }

    nebulae.push({
      id,
      label: CLUSTER_LABELS[id] || id,
      center: data.center,
      color: data.color,
      colorAlt: data.colorAlt,
      paperCount: data.paperCount,
      coreParticles,
      coreColors,
      coreSizes,
      haloParticles,
      haloColors,
      haloSizes,
    })
  }

  return nebulae
}
