import { useEffect, useState, useMemo, useCallback } from 'react'
import { Canvas } from '@react-three/fiber'
import { Search } from 'lucide-react'
import { useGraphStore } from '../stores/graph'
import { FrontierScene } from '../components/frontier/FrontierScene'
import { ClusterFilter } from '../components/frontier/ClusterFilter'
import { ClusterTooltip } from '../components/frontier/ClusterTooltip'
import { generateMockGraph, generateNebulae } from '../data/mockGraph'
import { fetchGraph } from '../api/graph'
import '../styles/frontier.css'

export default function Frontier() {
  const nodes = useGraphStore((s) => s.nodes)
  const edges = useGraphStore((s) => s.edges)
  const searchQuery = useGraphStore((s) => s.searchQuery)
  const visibleClusters = useGraphStore((s) => s.visibleClusters)
  const clusters = useGraphStore((s) => s.clusters)
  const setNodes = useGraphStore((s) => s.setNodes)
  const setEdges = useGraphStore((s) => s.setEdges)
  const setSearch = useGraphStore((s) => s.setSearch)

  const [loading, setLoading] = useState(true)
  const [selectedCluster, setSelectedCluster] = useState<string | null>(null)

  const nebulae = useMemo(() => generateNebulae(), [])

  useEffect(() => {
    let cancelled = false

    async function load() {
      try {
        const data = await fetchGraph('default')
        if (!cancelled) {
          setNodes(data.nodes)
          setEdges(data.edges)
        }
      } catch {
        if (!cancelled) {
          const mock = generateMockGraph()
          setNodes(mock.nodes)
          setEdges(mock.edges)
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    load()
    return () => { cancelled = true }
  }, [setNodes, setEdges])

  const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value)
  }, [setSearch])

  const selectedNebula = selectedCluster ? nebulae.find((n) => n.id === selectedCluster) : null
  const totalPapers = nebulae.reduce((s, n) => s + n.paperCount, 0)

  if (loading) {
    return (
      <div className="frontier-container">
        <div className="frontier-loading">
          <div className="frontier-loading-inner">
            <div className="frontier-loading-ring" />
            <div className="frontier-loading-text">Mapping research universe...</div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="frontier-container">
      <div className="frontier-canvas">
        <Canvas
          camera={{ position: [0, 5, 55], fov: 55, near: 0.1, far: 300 }}
          dpr={[1, 2]}
          gl={{ antialias: true, alpha: false, powerPreference: 'high-performance' }}
        >
          <FrontierScene
            nebulae={nebulae}
            visibleClusters={visibleClusters}
            selectedCluster={selectedCluster}
            onSelectCluster={setSelectedCluster}
          />
        </Canvas>
      </div>

      <div className="frontier-hud">
        <div className="frontier-top-bar">
          <div className="frontier-title-block">
            <h2 className="frontier-title">FRONTIER</h2>
            <span className="frontier-subtitle">
              {totalPapers.toLocaleString()} papers &middot; {clusters.length} research domains
            </span>
          </div>

          <div className="frontier-view-modes">
            <button className="frontier-view-btn active">Explore</button>
            <button className="frontier-view-btn">Fly</button>
            <button className="frontier-view-btn">Focus</button>
            <button className="frontier-view-btn">Filters</button>
          </div>
        </div>

        <div className="frontier-search-bar">
          <Search size={14} className="frontier-search-icon" />
          <input
            type="text"
            placeholder="Search arXiv, authors, ideas..."
            value={searchQuery}
            onChange={handleSearchChange}
          />
          <kbd className="frontier-search-kbd">⌘K</kbd>
        </div>

        <ClusterFilter />

        {selectedNebula && (
          <ClusterTooltip
            nebula={selectedNebula}
            nodes={nodes}
            edges={edges}
            onClose={() => setSelectedCluster(null)}
          />
        )}

        <div className="frontier-hint">
          Drag to rotate &middot; Scroll to zoom &middot; Click a cluster to explore
        </div>
      </div>
    </div>
  )
}
