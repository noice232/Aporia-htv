import { useCallback } from 'react'
import { OrbitControls } from '@react-three/drei'
import { EffectComposer, Bloom } from '@react-three/postprocessing'
import { NebulaCloud } from './NebulaCloud'
import { ClusterLabel } from './ClusterLabel'
import { StarField } from './StarField'
import { InterClusterLinks } from './InterClusterLinks'
import type { NebulaCluster } from '../../data/mockGraph'

interface FrontierSceneProps {
  nebulae: NebulaCluster[]
  visibleClusters: Set<string>
  selectedCluster: string | null
  onSelectCluster: (id: string | null) => void
}

export function FrontierScene({ nebulae, visibleClusters, selectedCluster, onSelectCluster }: FrontierSceneProps) {
  const handleMissClick = useCallback(() => {
    onSelectCluster(null)
  }, [onSelectCluster])

  const handleSelectCluster = useCallback((id: string) => {
    onSelectCluster(selectedCluster === id ? null : id)
  }, [selectedCluster, onSelectCluster])

  return (
    <>
      <color attach="background" args={[0.018, 0.025, 0.045]} />
      <fog attach="fog" args={[0x050710, 60, 180]} />

      <ambientLight intensity={0.08} />
      <pointLight position={[30, 30, 30]} intensity={0.15} color="#57DDF6" />
      <pointLight position={[-25, -15, -30]} intensity={0.1} color="#B99AFF" />

      <StarField count={5000} />

      <group onClick={handleMissClick}>
        <mesh visible={false}>
          <sphereGeometry args={[150, 8, 8]} />
          <meshBasicMaterial side={1} />
        </mesh>
      </group>

      <InterClusterLinks nebulae={nebulae.filter((n) => visibleClusters.has(n.id))} />

      {nebulae.map((nebula) => (
        <NebulaCloud
          key={nebula.id}
          nebula={nebula}
          isVisible={visibleClusters.has(nebula.id)}
          isSelected={selectedCluster === nebula.id}
        />
      ))}

      {nebulae.filter((n) => visibleClusters.has(n.id)).map((nebula) => (
        <ClusterLabel
          key={nebula.id}
          nebula={nebula}
          isSelected={selectedCluster === nebula.id}
          onSelect={handleSelectCluster}
        />
      ))}

      <OrbitControls
        makeDefault
        enableDamping
        dampingFactor={0.04}
        minDistance={8}
        maxDistance={120}
        enablePan
        panSpeed={0.4}
        rotateSpeed={0.35}
        zoomSpeed={0.7}
        autoRotate
        autoRotateSpeed={0.15}
      />

      <EffectComposer>
        <Bloom
          luminanceThreshold={0.1}
          luminanceSmoothing={0.95}
          intensity={1.5}
          mipmapBlur
        />
      </EffectComposer>
    </>
  )
}
