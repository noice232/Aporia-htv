import { Html } from '@react-three/drei'
import type { NebulaCluster } from '../../data/mockGraph'

interface ClusterLabelProps {
  nebula: NebulaCluster
  isSelected: boolean
  onSelect: (id: string) => void
}

export function ClusterLabel({ nebula, isSelected, onSelect }: ClusterLabelProps) {
  const color = `rgb(${nebula.color.map((c) => Math.round(c * 255)).join(',')})`

  return (
    <Html
      position={[nebula.center[0], nebula.center[1] + 7, nebula.center[2]]}
      center
      distanceFactor={25}
      style={{ pointerEvents: 'auto', cursor: 'pointer' }}
      onClick={() => onSelect(nebula.id)}
    >
      <div style={{
        textAlign: 'center',
        userSelect: 'none',
        transform: isSelected ? 'scale(1.1)' : 'scale(1)',
        transition: 'transform 0.3s ease',
      }}>
        <div style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 14,
          fontWeight: 600,
          color: isSelected ? '#E5EFFA' : color,
          letterSpacing: '0.08em',
          whiteSpace: 'nowrap',
          textShadow: `0 0 20px ${color}44, 0 0 40px ${color}22, 0 2px 8px rgba(0,0,0,0.6)`,
          marginBottom: 4,
        }}>
          {nebula.label}
        </div>
        <div style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: 10,
          color: 'rgba(136, 152, 175, 0.8)',
          letterSpacing: '0.04em',
          textShadow: '0 1px 4px rgba(0,0,0,0.6)',
        }}>
          {nebula.paperCount.toLocaleString()} papers
        </div>
      </div>
    </Html>
  )
}
