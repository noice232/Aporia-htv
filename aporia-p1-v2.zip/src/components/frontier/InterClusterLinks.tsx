import { useMemo } from 'react'
import { BufferGeometry, Float32BufferAttribute, AdditiveBlending } from 'three'
import type { NebulaCluster } from '../../data/mockGraph'

interface InterClusterLinksProps {
  nebulae: NebulaCluster[]
}

export function InterClusterLinks({ nebulae }: InterClusterLinksProps) {
  const geometry = useMemo(() => {
    const positions: number[] = []

    for (let i = 0; i < nebulae.length; i++) {
      for (let j = i + 1; j < nebulae.length; j++) {
        const a = nebulae[i]
        const b = nebulae[j]
        const particlesPerLink = 30

        for (let k = 0; k < particlesPerLink; k++) {
          const t = k / (particlesPerLink - 1)
          const jitter = 1.5
          positions.push(
            a.center[0] * (1 - t) + b.center[0] * t + (Math.random() - 0.5) * jitter,
            a.center[1] * (1 - t) + b.center[1] * t + (Math.random() - 0.5) * jitter,
            a.center[2] * (1 - t) + b.center[2] * t + (Math.random() - 0.5) * jitter,
          )
        }
      }
    }

    const geo = new BufferGeometry()
    geo.setAttribute('position', new Float32BufferAttribute(positions, 3))
    return geo
  }, [nebulae])

  return (
    <points geometry={geometry}>
      <pointsMaterial
        color={[0.4, 0.5, 0.7]}
        size={0.04}
        transparent
        opacity={0.15}
        blending={AdditiveBlending}
        depthWrite={false}
        sizeAttenuation
      />
    </points>
  )
}
