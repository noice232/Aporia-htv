import type { NebulaCluster } from '../../data/mockGraph'
import type { GraphNode, GraphEdge } from '../../stores/graph'

interface ClusterTooltipProps {
  nebula: NebulaCluster
  nodes: GraphNode[]
  edges: GraphEdge[]
  onClose: () => void
}

export function ClusterTooltip({ nebula, nodes, edges, onClose }: ClusterTooltipProps) {
  const clusterNodes = nodes.filter((n) => n.cluster === nebula.id)
  const clusterEdges = edges.filter((e) => {
    const sn = nodes.find((n) => n.id === e.source)
    const tn = nodes.find((n) => n.id === e.target)
    return sn?.cluster === nebula.id || tn?.cluster === nebula.id
  })
  const color = `rgb(${nebula.color.map((c) => Math.round(c * 255)).join(',')})`

  return (
    <div className="frontier-tooltip">
      <div className="frontier-tooltip-header">
        <div className="frontier-tooltip-name">
          <span className="frontier-tooltip-dot" style={{ background: color, boxShadow: `0 0 8px ${color}` }} />
          {nebula.label}
        </div>
        <button className="frontier-tooltip-close" onClick={onClose} aria-label="Close">&#x2715;</button>
      </div>

      <div className="frontier-tooltip-stats">
        <div className="frontier-tooltip-stat">
          <span className="frontier-tooltip-stat-value">{nebula.paperCount.toLocaleString()}</span>
          <span className="frontier-tooltip-stat-label">papers</span>
        </div>
        <div className="frontier-tooltip-stat">
          <span className="frontier-tooltip-stat-value">{clusterEdges.length}</span>
          <span className="frontier-tooltip-stat-label">connections</span>
        </div>
      </div>

      {clusterNodes.length > 0 && (
        <div className="frontier-tooltip-papers">
          <div className="frontier-tooltip-section-title">Key Papers</div>
          {clusterNodes.slice(0, 6).map((node) => {
            const meta = node.metadata as Record<string, unknown> | undefined
            return (
              <div key={node.id} className="frontier-tooltip-paper">
                <div className="frontier-tooltip-paper-title">{node.label}</div>
                <div className="frontier-tooltip-paper-meta">
                  {meta?.venue && <span>{String(meta.venue)}</span>}
                  {meta?.year && <span>{String(meta.year)}</span>}
                  {meta?.citations != null && <span>{String(meta.citations)} cites</span>}
                </div>
              </div>
            )
          })}
        </div>
      )}

      <div className="frontier-tooltip-keywords">
        {['transformer', 'attention', 'self-supervised', 'few-shot', 'pre-training'].map((kw) => (
          <span key={kw} className="frontier-tooltip-kw">{kw}</span>
        ))}
      </div>
    </div>
  )
}
