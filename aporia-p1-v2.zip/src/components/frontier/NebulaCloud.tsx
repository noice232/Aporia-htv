import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import { AdditiveBlending, BufferGeometry, Float32BufferAttribute, ShaderMaterial, Points } from 'three'
import type { NebulaCluster } from '../../data/mockGraph'

const vertexShader = `
  attribute float aSize;
  attribute vec3 aColor;
  attribute float aPhase;
  varying vec3 vColor;
  varying float vAlpha;
  uniform float uTime;
  uniform float uSelected;

  void main() {
    vColor = aColor;
    vec3 pos = position;
    float wave = sin(uTime * 0.3 + aPhase) * 0.15;
    pos += normal * wave;

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    float dist = -mvPosition.z;
    gl_PointSize = aSize * (180.0 / dist);
    gl_PointSize = max(gl_PointSize, 1.0);

    vAlpha = smoothstep(100.0, 20.0, dist) * (0.6 + sin(uTime * 0.5 + aPhase * 3.0) * 0.15);
    vAlpha *= mix(0.3, 1.0, uSelected);

    gl_Position = projectionMatrix * mvPosition;
  }
`

const fragmentShader = `
  varying vec3 vColor;
  varying float vAlpha;

  void main() {
    float d = length(gl_PointCoord - vec2(0.5));
    if (d > 0.5) discard;

    float glow = exp(-d * d * 8.0);
    float core = smoothstep(0.5, 0.0, d);
    float intensity = glow * 0.6 + core * 0.4;

    gl_FragColor = vec4(vColor * intensity * 1.8, vAlpha * intensity);
  }
`

interface NebulaCloudProps {
  nebula: NebulaCluster
  isVisible: boolean
  isSelected: boolean
}

export function NebulaCloud({ nebula, isVisible, isSelected }: NebulaCloudProps) {
  const coreRef = useRef<Points>(null)
  const haloRef = useRef<Points>(null)
  const coreMat = useRef<ShaderMaterial>(null)
  const haloMat = useRef<ShaderMaterial>(null)

  const coreGeo = useMemo(() => {
    const geo = new BufferGeometry()
    geo.setAttribute('position', new Float32BufferAttribute(nebula.coreParticles, 3))
    geo.setAttribute('aColor', new Float32BufferAttribute(nebula.coreColors, 3))
    geo.setAttribute('aSize', new Float32BufferAttribute(nebula.coreSizes, 1))
    const phases = new Float32Array(nebula.coreSizes.length)
    for (let i = 0; i < phases.length; i++) phases[i] = Math.random() * Math.PI * 2
    geo.setAttribute('aPhase', new Float32BufferAttribute(phases, 1))
    const normals = new Float32Array(nebula.coreParticles.length)
    for (let i = 0; i < normals.length; i++) normals[i] = (Math.random() - 0.5) * 2
    geo.setAttribute('normal', new Float32BufferAttribute(normals, 3))
    return geo
  }, [nebula])

  const haloGeo = useMemo(() => {
    const geo = new BufferGeometry()
    geo.setAttribute('position', new Float32BufferAttribute(nebula.haloParticles, 3))
    geo.setAttribute('aColor', new Float32BufferAttribute(nebula.haloColors, 3))
    geo.setAttribute('aSize', new Float32BufferAttribute(nebula.haloSizes, 1))
    const phases = new Float32Array(nebula.haloSizes.length)
    for (let i = 0; i < phases.length; i++) phases[i] = Math.random() * Math.PI * 2
    geo.setAttribute('aPhase', new Float32BufferAttribute(phases, 1))
    const normals = new Float32Array(nebula.haloParticles.length)
    for (let i = 0; i < normals.length; i++) normals[i] = (Math.random() - 0.5) * 2
    geo.setAttribute('normal', new Float32BufferAttribute(normals, 3))
    return geo
  }, [nebula])

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime()
    if (coreMat.current) {
      coreMat.current.uniforms.uTime.value = t
      coreMat.current.uniforms.uSelected.value = isSelected ? 1.0 : isVisible ? 0.7 : 0.15
    }
    if (haloMat.current) {
      haloMat.current.uniforms.uTime.value = t
      haloMat.current.uniforms.uSelected.value = isSelected ? 1.0 : isVisible ? 0.5 : 0.08
    }
  })

  if (!isVisible) return null

  return (
    <group>
      <points ref={coreRef} geometry={coreGeo}>
        <shaderMaterial
          ref={coreMat}
          vertexShader={vertexShader}
          fragmentShader={fragmentShader}
          uniforms={{
            uTime: { value: 0 },
            uSelected: { value: 0.7 },
          }}
          transparent
          blending={AdditiveBlending}
          depthWrite={false}
        />
      </points>
      <points ref={haloRef} geometry={haloGeo}>
        <shaderMaterial
          ref={haloMat}
          vertexShader={vertexShader}
          fragmentShader={fragmentShader}
          uniforms={{
            uTime: { value: 0 },
            uSelected: { value: 0.5 },
          }}
          transparent
          blending={AdditiveBlending}
          depthWrite={false}
        />
      </points>
    </group>
  )
}
